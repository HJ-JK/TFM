import getpass
import os
import json
from langchain_core.output_parsers import StrOutputParser
from langchain_core.chat_history import (
    BaseChatMessageHistory,
    InMemoryChatMessageHistory,
) # Para almacenar el historial de mensajes de chat
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain_core.messages import HumanMessage, SystemMessage, AIMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, trim_messages
from langchain_community.document_loaders import PyPDFLoader
from langchain_community.vectorstores import FAISS
from langchain_openai import OpenAIEmbeddings
from langchain_community.document_loaders import PyPDFium2Loader


store = {}

SESSION_DIR = "sessions_file"
os.makedirs(SESSION_DIR, exist_ok=True)

# Convierte un mensaje en un diccionario serializable a JSON
def message_to_dict(message):
    return {
        'type': message.__class__.__name__,  # Guarda el tipo de mensaje
        'content': message.content,
        'metadata': message.response_metadata if hasattr(message, 'response_metadata') else {}
    }

# Convierte un diccionario en un objeto de mensaje.
def dict_to_message(message_dict):
    if message_dict['type'] == 'HumanMessage':
        return HumanMessage(content=message_dict['content'])
    elif message_dict['type'] == 'AIMessage':
        return AIMessage(
            content=message_dict['content'],
            response_metadata=message_dict.get('metadata', {})
        )
    else:
        raise ValueError(f"Tipo de mensaje desconocido: {message_dict['type']}")

# Convierte el historial de mensajes en un diccionario serializable a JSON.
def history_to_dict(history: BaseChatMessageHistory) -> dict:
    messages = history.messages
    return [message_to_dict(message) for message in messages]

# Convierte un diccionario que representa el historial de mensajes 
# en una instancia de BaseChatMessageHistory.
def dict_to_history(history_dict: dict) -> BaseChatMessageHistory:
    history = InMemoryChatMessageHistory()
    for message_dict in history_dict:
        message = dict_to_message(message_dict)
        history.add_message(message)
    return history

# Almacena el historial de la sesión en SESSION_DIR
def save_session_history(session_id: str, history: BaseChatMessageHistory):
    file_path = os.path.join(SESSION_DIR, f"{session_id}.json")
    with open(file_path, 'w') as file:
        json.dump(history_to_dict(history), file)
    print(f"Historial de sesión {session_id} guardado en {file_path}")

# Cargar el historial de la sesión en SESSION_DIR
def load_session_history(session_id: str) -> BaseChatMessageHistory:
    file_path = os.path.join(SESSION_DIR, f"{session_id}.json")
    if not os.path.exists(file_path):
        print(f"No se encontró historial para la sesión {session_id}")
        return InMemoryChatMessageHistory()

    with open(file_path, 'r') as file:
        history_dict = json.load(file)
    
    return dict_to_history(history_dict)

# Obtener el historial de la sesión en store
def get_session_history(session_id: str) -> BaseChatMessageHistory:
    if session_id not in store:
        store[session_id] = load_session_history(session_id)
    return store[session_id]


parser = StrOutputParser() # Parsear la salida del modelo de lenguaje en formato string
os.environ["OPENAI_API_KEY"] = "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"

model = ChatOpenAI(model="gpt-4o")

trimmer = trim_messages(
    max_tokens=1000000,
    strategy="last",
    token_counter=model,
    include_system=True,
    allow_partial=False,
    start_on="human",
) # Configura para recortar y ajustar la longitud de los mensajes

prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You are a helpful assistant. You will answer questions about file contents, i will give you file name and content.",
        ),
        MessagesPlaceholder(variable_name="messages"),
    ]
) # Proporciona instrucciones al modelo de lenguaje

chain = prompt | model # Cadena de procesamiento en la que el prompt se pasa al model. 
# Combina la cadena de procesamiento con la func de mantener el historial de mensajes.
with_message_history = RunnableWithMessageHistory(chain, get_session_history) 
config = {"configurable": {"session_id": "abc2"}}
UPLOAD_DIRECTORY = "uploaded_files/"

# Procesa el mensaje de chat y devuelve una respuesta.
def chat(session_id, prompt, filename=None):
    config = {"configurable": {"session_id": session_id}}
    print(config)
    prompt_of_file = ""

    if filename is None:  # Procesamiento sin archivos
        messages = [HumanMessage(content=prompt)]
        response = with_message_history.invoke(messages, config=config)
    else:  # Procesamiento con archivos
        for file_item in filename:
            file_content = ""
            if '.pdf' in file_item:
                loader = PyPDFium2Loader(UPLOAD_DIRECTORY + file_item)
                data = loader.load()
                page_index = 1
                for page in data:
                    file_content += f"page{page_index}: {str(page)} \n"
                    page_index += 1
            elif '.txt' in file_item:
                with open(UPLOAD_DIRECTORY + file_item, 'r') as file:
                    file_content = file.read()
            prompt_of_file += f"""
                File name: `{file_item}`
                File content: `{file_content}`
            """
        messages = [
            HumanMessage(content=prompt_of_file),
            HumanMessage(content=prompt)
        ]
        response = with_message_history.invoke(messages, config=config)

    # Guarda el historial actualizado
    save_session_history(session_id, get_session_history(session_id))

    return response.content
