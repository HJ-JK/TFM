from fastapi import FastAPI, File, UploadFile, Form, Query, HTTPException
import os
from typing import List, Optional
import uuid
from chat import chat, get_session_history, history_to_dict
import shutil
from pydantic import BaseModel
import base64
import requests
from fastapi.middleware.cors import CORSMiddleware
import base64

app = FastAPI()

# Directorio donde se guardarán los archivos subidos
UPLOAD_DIRECTORY = "uploaded_files"

if not os.path.exists(UPLOAD_DIRECTORY):
    os.makedirs(UPLOAD_DIRECTORY)

# Define el directorio donde se guardarán los archivos de audio
AUDIO_DIR = "audio_files"
os.makedirs(UPLOAD_DIRECTORY + "/" + AUDIO_DIR, exist_ok=True)

# Directorio para los archivos de textos generados por el modelo text generation
TEXT_DIR = "saved_texts"
os.makedirs(UPLOAD_DIRECTORY + "/" + TEXT_DIR, exist_ok=True)

# Directorio donde se almacenan los archivos de sesión
SESSION_DIR = "sessions_file"


# Configuración del middleware CORS para permitir solicitudes desde orígenes específicos
origins = [
    "http://localhost",
    "http://localhost:8080",
    "http://localhost:4200",
]


app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,  # Orígenes permitidos
    allow_credentials=True,
    allow_methods=["*"],  # Permitir todos los métodos HTTP
    allow_headers=["*"],  # Permitir todos los encabezados HTTP
)

# Endpoint para subir archivos
@app.post("/upload/")
async def upload_file(file: UploadFile = File(...), folder_path: str = Form("")):
    # Construye la ruta completa del directorio donde se guardará el archivo
    full_directory = os.path.join(UPLOAD_DIRECTORY, folder_path) if folder_path else UPLOAD_DIRECTORY
    print(full_directory)
    
    # Construye la ruta completa del archivo
    if not os.path.exists(full_directory):
        os.makedirs(full_directory)
    
    # Construye la ruta completa del archivo incluyendo el nombre del archivo
    file_location = os.path.join(full_directory, file.filename)
    
    # Guardar el archivo
    with open(file_location, "wb+") as file_object:
        file_object.write(file.file.read())
    
    return {"info": f"file '{file.filename}' saved at '{file_location}'"}


class FileItem(BaseModel):
    name: str
    isFile: bool
    path: str
# Endpoint para listar archivos y carpetas en un directorio
@app.get("/files/", response_model=List[FileItem])
async def list_files(folder_path: str = Query("", alias="folder")):
    full_directory = os.path.join(UPLOAD_DIRECTORY, folder_path)
    
    # Verificación del directorio
    if not os.path.exists(full_directory):
        raise HTTPException(status_code=404, detail="Directory does not exist")
    
    if not os.path.isdir(full_directory):
        raise HTTPException(status_code=400, detail="Provided path is not a directory")
    
    # Lista los archivos y directorios
    items = []
    for item in os.listdir(full_directory):
        file_path = os.path.join(full_directory, item)
        item_path = os.path.relpath(os.path.join(full_directory, item), UPLOAD_DIRECTORY)
        item_path = item_path.replace(os.path.sep, "/")

        items.append(FileItem(name=item, isFile=os.path.isfile(file_path), path=item_path))
    
    return items


class FileInfo(BaseModel):
    name: str
    isFile: bool
    path: str
    children: list['FileInfo'] = None
# Recorrer un directorio y sus subdirectorios para crear una lista de objetos FileInfo
def get_directory_contents(path: str, relative_path: str) -> List[FileInfo]:
    items = []
    for item in os.listdir(path):
        item_path = os.path.join(path, item)
        item_relative_path = os.path.join(relative_path, item)
        if os.path.isdir(item_path):
            items.append(FileInfo(name=item, isFile=False, path=item_relative_path, 
                                  children=get_directory_contents(item_path, item_relative_path)))
        else:
            items.append(FileInfo(name=item, isFile=True, path=item_relative_path))
    return items
# Endpoint para listar archivos y carpetas de forma recursiva en el árbol de archivos
@app.get("/all-files/", response_model=List[FileInfo])
async def list_files(folder_path: str = Query("", alias="folder")):
    full_directory = os.path.join(UPLOAD_DIRECTORY, folder_path)
    
    # Verificación del directorio
    if not os.path.exists(full_directory):
        raise HTTPException(status_code=404, detail="Directory does not exist")
    
    if not os.path.isdir(full_directory):
        raise HTTPException(status_code=400, detail="Provided path is not a directory")
    
    return get_directory_contents(full_directory, folder_path)


class FolderRequest(BaseModel):
    folder_path: str
# Endpoint para crear una nueva carpeta
@app.post("/create_folder/")
async def create_folder(request: FolderRequest):
    # Construye la ruta completa de la carpeta
    full_directory = os.path.join(UPLOAD_DIRECTORY, request.folder_path)
    print(full_directory)
    
    # Verifica si la carpeta ya existe
    if os.path.exists(full_directory):
        raise HTTPException(status_code=400, detail="Folder already exists")

    # Crea la nueva carpeta
    os.makedirs(full_directory)
    
    return {"info": f"folder '{request.folder_path}' created at '{full_directory}'"}


class ChatRequest(BaseModel):
    sessionid: Optional[str] = None # ID de sesión opcional; se genera uno nuevo si no se proporciona
    humanText: str
    filename: Optional[List[str]] = None
# Endpoint para enviar un prompt de chat y obtener una respuesta del modelo
@app.post("/chat/")
async def submit_prompt(request: ChatRequest):
    # Genera un sessionid si el id proporcionado es vacío o None
    if not request.sessionid:
        request.sessionid = "session_" + str(uuid.uuid4())[0:8]

    # Llama a la función de chat con el ID de sesión, el texto del humano y el nombre del archivo
    robotMessage = chat(request.sessionid, request.humanText, filename=request.filename)
    return {"sessionid": request.sessionid, "robotMessage": robotMessage}

# Endpoint para obtener la lista de sesiones ids disponibles
@app.get("/sessions/")
async def get_sessions():
    # Lista de archivos de sesión en el directorio SESSION_DIR
    session_files = [f for f in os.listdir(SESSION_DIR) if f.endswith('.json')]
    # Extrae los IDs de sesión eliminando la extensión de archivo
    session_ids = [os.path.splitext(f)[0] for f in session_files]
    return {"sessions": session_ids}

# Endpoint para obtener el historial de una sesión específica
@app.get("/sessions/{session_id}/")
async def get_session_hist(session_id: str):
    try:
        # Obtiene el historial de la sesión usando el sessionid proporcionado
        history = get_session_history(session_id)
        return {
            "session_id": session_id,
            "history": history_to_dict(history)  # Convertimos el historial a un formato serializable
        }
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Session not found")

# Endpoint para eliminar una sesión específica
@app.delete("/sessions/{session_id}")
async def delete_session(session_id: str):
    # Construir el nombre del archivo basado en session_id
    file_path = os.path.join(SESSION_DIR, f"{session_id}.json")
    
    # Verificar si el archivo existe
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail=f"Session file '{session_id}.json' not found")

    try:
        # Intentar eliminar el archivo
        os.remove(file_path)
        return {"detail": f"Session '{session_id}' deleted successfully"}
    except Exception as e:
        # Manejar cualquier otro error que pueda ocurrir
        raise HTTPException(status_code=500, detail=f"Failed to delete session '{session_id}': {str(e)}")


# Endpoint para eliminar un archivo o carpeta
@app.delete("/delete/")
async def delete_item(item_path: str = Query(...)):
    full_path = os.path.join(UPLOAD_DIRECTORY, item_path)
    
    # Verifica la existencia del archivo o directorio
    if not os.path.exists(full_path):
        raise HTTPException(status_code=404, detail="File or directory does not exist")
    
    # Elimina el archivo o directorio
    if os.path.isfile(full_path):
        os.remove(full_path)
    elif os.path.isdir(full_path):
        os.rmdir(full_path)
    else:
        raise HTTPException(status_code=400, detail="Provided path is neither a file nor a directory")
    
    return {"info": f"'{item_path}' has been deleted"}


# Endpoint para copiar un archivo
@app.post("/copy/")
async def copy_file(old_file_path: str = Query(...), new_file_path: str = Query(...)):
    full_old_path = os.path.join(UPLOAD_DIRECTORY, old_file_path)
    full_new_path = os.path.join(UPLOAD_DIRECTORY, new_file_path)
    
    # Verificar la existencia del archivo original
    if not os.path.exists(full_old_path):
        raise HTTPException(status_code=404, detail="Old file does not exist")
    
    # Verifica que el archivo origen sea un archivo
    if not os.path.isfile(full_old_path):
        raise HTTPException(status_code=400, detail="Old path is not a file")
    
    # Asegura que existe el directorio destino
    new_directory = os.path.dirname(full_new_path)
    if not os.path.exists(new_directory):
        os.makedirs(new_directory)
    
    # Copiar archivo
    shutil.copy2(full_old_path, full_new_path)
    
    return {"info": f"file copied from '{old_file_path}' to '{new_file_path}'"}

# Deserializa automáticamente el JSON en una instancia de la clase DocQaRequest
class DocQaRequest(BaseModel):
    filename: str
    qt: str
# Endpoint para realizar una consulta QA a un documento
@app.post("/docqa/")
async def docqa(request: DocQaRequest):
    filename = request.filename
    qt = request.qt
    full_path = os.path.join(UPLOAD_DIRECTORY, filename)
    
    # Verifica la existencia del documento
    if not os.path.exists(full_path):
        raise HTTPException(status_code=404, detail="File does not exist")
    
    # Lee el documento y convierte a una cadena en base64
    with open(full_path, "rb") as file:
        file_content = file.read()
        encoded_file = base64.b64encode(file_content).decode('utf-8')

    # Realiza una solicitud POST a la API de Hugging Face 
    response = requests.post(
        "https://api-inference.huggingface.co/models/impira/layoutlm-document-qa",
        headers={
            "Authorization": "Bearer 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",
            "Content-Type": "application/json"
        },
        json={
            "inputs": {
                "question": qt,
                "image": encoded_file
            }
        }
    )
    # Verifica la respuesta de la API
    if response.status_code != 200:
        print(response)
        raise HTTPException(status_code=response.status_code, detail="Error calling Hugging Face API")

    result = response.json()
    return result

class AudioRequest(BaseModel):
    audio: str
    name: str
@app.post("/asr/")
async def asr(request: AudioRequest):
    # Obtiene la cadena Base64 del campo `audio`
    audio_data = request.audio

    # Decodifica la cadena Base64 a bytes
    audio_bytes = base64.b64decode(audio_data)

    # Genera una ruta única para el archivo audio
    file_path = os.path.join(UPLOAD_DIRECTORY + "/" + AUDIO_DIR, request.name)

    # Guarda el archivo de audio en el directorio especificado
    with open(file_path, "wb") as audio_file:
        audio_file.write(audio_bytes)

    # Realiza una solicitud POST a la API de Hugging Face 
    response = requests.post(
        "https://api-inference.huggingface.co/models/openai/whisper-large-v3",
        headers={
            "Authorization": "Bearer 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"
        },
        data = audio_bytes
    )
    # Verifica la respuesta de la API
    if response.status_code != 200:
        print(response.text)
        raise HTTPException(status_code=response.status_code, detail="Error calling Hugging Face API")

    result = response.json()

    # Especifica la ruta y el nombre del archivo .txt donde se guardará la transcripción
    file_name = "audioTotext_" + os.path.splitext(request.name)[0] + ".txt"
    file_path = os.path.join(UPLOAD_DIRECTORY + "/" + AUDIO_DIR, file_name)
    # Guarda el texto transcrito en un archivo .txt
    with open(file_path, 'w') as file:
        file.write(result["text"])
    
    return result


class TextRequest(BaseModel):
    texts: str
@app.post("/tg/")
async def tg(request: TextRequest):
    # Obtiene la cadena Base64 del campo `audio`
    text_data = request.texts

    # Realiza una solicitud POST a la API de Hugging Face 
    response = requests.post(
        "https://api-inference.huggingface.co/models/google/gemma-7b",
        headers={
            "Authorization": "Bearer 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",
            "Content-Type": "application/json"
        },
        json={
            "inputs": text_data
        }
    )
    # Verifica la respuesta de la API
    if response.status_code != 200:
        print(response.text)
        raise HTTPException(status_code=response.status_code, detail="Error calling Hugging Face API")

    result = response.json()

    # Define la ruta del archivo
    file_name = "generated_text_" + str(uuid.uuid4())[0:8] + ".txt"
    file_path = os.path.join(UPLOAD_DIRECTORY + "/" + TEXT_DIR, file_name)


    # Guarda el texto en un archivo .txt
    with open(file_path, 'w') as file:
        file.write(result[0]["generated_text"])

    # Devuelve la respuesta
    return {"file_path": file_path, "generated_text": result[0].get('generated_text', '')}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
